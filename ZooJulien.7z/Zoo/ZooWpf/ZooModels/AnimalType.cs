﻿using System;

namespace ZooWpf.ZooModels
{
    public class AnimalType
    {
        private Guid _id;
        private string _name;
        public AnimalType(string typeName, string imgLink)
        {
            _id = Guid.NewGuid();
            _name = typeName;
        }
        public Guid Id
        {
            get { return _id; }
            set { _id = value; }
        }
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        private string _imgLink;

        public string ImgLink
        {
            get { return _imgLink; }
            set { _imgLink = value; }
        }

    }
}