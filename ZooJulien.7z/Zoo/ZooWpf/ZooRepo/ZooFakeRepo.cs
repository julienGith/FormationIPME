﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ZooWpf.ZooModels;

namespace ZooWpf.ZooRepo
{
    public class ZooFakeRepo : IZooFakeRepo
    {
        public List<Animal> GetAllAnimals()
        {
            var type1 = new AnimalType("Chien", "https://cdn-icons-png.flaticon.com/512/194/194279.png");
            var type2 = new AnimalType("Chat", "http://cdn.onlinewebfonts.com/svg/img_547265.png");
            var animals = new List<Animal>() { 
                new Animal("Akita Américain",type1),
                new Animal("Basset Bleu de Gascogne",type1),
                new Animal("Berger Catalan",type1),
                new Animal("Labradoodle",type1),
                new Animal("Abyssin",type2),
                new Animal("Havana Brown",type2),
                new Animal("Scottish Fold",type2),
                new Animal("York Chocolat",type2),
            };
            return animals;
        }
    }
}
